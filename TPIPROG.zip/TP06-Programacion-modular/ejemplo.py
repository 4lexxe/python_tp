def calcular_area(base, altura):
    return base * altura

# Aquí, se especifica que 'base' es 5 y 'altura' es 10
area2 = calcular_area(base=5, altura=10)
print("Área usando argumentos por palabras clave:", area2)

# El orden puede cambiar y el resultado será el mismo
area3 = calcular_area(altura=10, base=5)
print("Área usando argumentos por palabras clave en orden diferente:", area3)