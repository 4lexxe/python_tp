def menorMayor(x, y):
    if x > y:
        return y, x
    else:
        return x, y

# Ingresar los tres números
a = int(input("Ingrese el primer número: "))
b = int(input("Ingrese el segundo número: "))
c = int(input("Ingrese el tercer número: "))

# Ordenar los números usando el módulo menorMayor
a, b = menorMayor(a, b)
a, c = menorMayor(a, c)
b, c = menorMayor(b, c)

# Imprimir los números en orden ascendente
print(f"Los números ordenados en forma ascendente son: {a}, {b}, {c}")
