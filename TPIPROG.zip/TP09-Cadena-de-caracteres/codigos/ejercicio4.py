# Paso [1]: Definir la función para verificar la dirección de correo electrónico
# Esta función comprueba si la cadena ingresada contiene exactamente un solo carácter "@".
def verificar_email(email):
    # Paso [1.1]: Contar cuántas veces aparece el carácter "@" en la dirección de correo electrónico.
    # Si aparece exactamente una vez, la dirección es considerada válida.
    if email.count('@') == 1:
        # Paso [1.2]: Retornar True si la dirección de correo electrónico es válida.
        return True
    else:
        # Paso [1.3]: Retornar False si la dirección de correo electrónico no es válida (no tiene exactamente un "@").
        return False

# Paso [2]: Solicitar al usuario que ingrese la dirección de correo electrónico
# Esta entrada será verificada para asegurarse de que contiene exactamente un "@".
direccion_email = input("Ingrese una dirección de correo electrónico: ")

# Paso [3]: Verificar si la dirección de correo electrónico contiene un solo "@"
# Llamamos a la función verificar_email para realizar esta comprobación.
if verificar_email(direccion_email):
    # Paso [3.1]: Si la función retorna True, la dirección de correo electrónico es válida.
    print("La dirección de correo electrónico es válida.")
else:
    # Paso [3.2]: Si la función retorna False, la dirección de correo electrónico no es válida.
    print("La dirección de correo electrónico no es válida. Debe contener exactamente un '@'.")
