''' Las cadenas en Python son estructuras de datos secuenciales que representan un conjunto ordenado de caracteres. 
Técnicamente, una cadena es un **objeto inmutable** que pertenece a la clase `str`, lo que significa que una vez creada, no puede ser modificada. 
Las cadenas son utilizadas para almacenar y manipular texto, lo cual puede incluir letras, números, símbolos y espacios.
Cada elemento de una cadena es un **carácter** y está asociado con un índice, que permite acceder y operar sobre los caracteres de forma individual. 
El índice en una cadena comienza en 0, lo que significa que el primer carácter tiene un índice de 0, el segundo un índice de 1, y así sucesivamente.
Las cadenas en Python soportan una variedad de operaciones, como la concatenación, repetición, partición, búsqueda, y
métodos específicos para transformar y analizar el contenido del texto. 
Debido a su naturaleza inmutable, cualquier operación que modifique una cadena en realidad crea una nueva cadena.

En un contexto más amplio, las cadenas pueden ser interpretadas como una implementación de **secuencias** de caracteres basadas en estándares de codificación como ASCII o Unicode, permitiendo así una representación eficaz de texto en computadoras y otros dispositivos digitales.'''


'''
1. **`str.capitalize()`**  
   Convierte el primer carácter de la cadena a mayúscula y el resto a minúsculas.

2. **`str.casefold()`**  
   Convierte la cadena a minúsculas de manera más agresiva que `str.lower()`, útil para comparaciones insensibles a mayúsculas.

3. **`str.center(width, fillchar)`**  
   Rellena la cadena con un carácter especificado hasta alcanzar un ancho determinado, centrando la cadena.

4. **`str.count(substring)`**  
   Cuenta el número de veces que aparece el `substring` en la cadena.

5. **`str.endswith(suffix)`**  
   Devuelve `True` si la cadena termina con el `suffix`, de lo contrario, `False`.

6. **`str.expandtabs(tabsize)`**  
   Reemplaza los tabuladores (`\t`) en la cadena con espacios, según el tamaño de tabulación especificado.

7. **`str.find(substring)`**  
   Devuelve el índice más bajo en el que se encuentra el `substring` en la cadena. Retorna `-1` si no se encuentra.

8. **`str.format(*args, **kwargs)`**  
   Realiza una interpolación de cadenas, permitiendo insertar valores en una cadena con marcadores de posición.

9. **`str.index(substring)`**  
   Similar a `find()`, pero lanza una excepción (`ValueError`) si el `substring` no se encuentra en la cadena.

10. **`str.isalnum()`**  
    Devuelve `True` si todos los caracteres en la cadena son alfanuméricos y la cadena no está vacía.

11. **`str.isalpha()`**  
    Devuelve `True` si todos los caracteres en la cadena son letras y la cadena no está vacía.

12. **`str.isdigit()`**  
    Devuelve `True` si todos los caracteres en la cadena son dígitos y la cadena no está vacía.

13. **`str.islower()`**  
    Devuelve `True` si todos los caracteres en la cadena están en minúsculas y hay al menos un carácter.

14. **`str.isspace()`**  
    Devuelve `True` si todos los caracteres en la cadena son espacios en blanco.

15. **`str.istitle()`**  
    Devuelve `True` si la cadena está en formato de título (cada palabra comienza con una letra mayúscula y el resto son minúsculas).

16. **`str.isupper()`**  
    Devuelve `True` si todos los caracteres en la cadena están en mayúsculas y hay al menos un carácter.

17. **`str.ljust(width, fillchar)`**  
    Rellena la cadena con el carácter especificado hasta alcanzar un ancho determinado, alineando la cadena a la izquierda.

18. **`str.lstrip(chars)`**  
    Elimina los caracteres especificados (o espacios en blanco por defecto) del inicio de la cadena.

19. **`str.replace(old, new)`**  
    Reemplaza todas las ocurrencias del `old` con el `new` en la cadena.

20. **`str.split(sep, maxsplit)`**  
    Divide la cadena en una lista usando el `sep` especificado (o espacio por defecto) y limita el número de divisiones a `maxsplit`.

Estos métodos proporcionan una amplia gama de funcionalidades para manipular y analizar cadenas de texto en Python.

'''