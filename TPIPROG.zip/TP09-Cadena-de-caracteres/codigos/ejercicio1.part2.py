def lee_edad():
    '''Solicitar una edad al usuario y validar la entrada'''
    
    # Paso [1]: Inicializar el contador de intentos en 0.
    i = 0

    # Paso [2]: Iniciar un bucle para permitir hasta 3 intentos.
    while i < 3:
        # Paso [3]: Incrementar el contador de intentos.
        i += 1

        # Paso [4]: Solicitar al usuario que ingrese su edad.
        valor = input(f'Intento {i}, edad:')

        # Paso [5]: Intentar convertir el valor ingresado a un número flotante.
        try:
            edad = float(valor)

            # Paso [6]: Verificar si la edad es menor o igual a 0.
            if edad <= 0.0:
                # Paso [7]: Imprimir un mensaje de error si la edad es inválida.
                print('La edad debe ser > 0')
            else:
                # Paso [8]: Si la edad es válida, retornar el valor y finalizar la función.
                return edad

        # Paso [9]: Capturar la excepción si la conversión falla y el valor no es un número.
        except ValueError:
            print('Dato inválido')

    # Paso [10]: Si se agotaron los 3 intentos, imprimir un mensaje de error y retornar `None`.
    print(f'Incorrecto! {i} intentos')
    return None

# Paso [11]: Llamar a la función lee_edad para obtener la edad del usuario.
edad = lee_edad()

# Paso [12]: Imprimir la edad retornada por la función (o None si hubo error).
print(edad)


'''

Prueba de escritorio:
Caso de prueba 1:

Entrada:
Intento 1: "25"
Proceso:
El usuario ingresa "25", que se convierte a 25.0.
La función retorna 25.0 y termina.
Salida esperada:
25.0
Caso de prueba 2:

Entrada:
Intento 1: "uno"
Intento 2: "30"
Proceso:
El usuario ingresa "uno", que no es un número, por lo que se muestra "Dato inválido".
En el segundo intento, ingresa "30", que se convierte a 30.0.
La función retorna 30.0 y termina.
Salida esperada:
"Dato inválido"
30.0
Caso de prueba 3:

Entrada:
Intento 1: "texto"
Intento 2: "palabra"
Intento 3: "palabra"
Proceso:
El usuario ingresa "texto", "palabra", y "palabra", que no son números, por lo que se muestra "Dato inválido" en cada intento.
Después de 3 intentos, la función imprime "Incorrecto! 3 intentos" y retorna None.
Salida esperada:
"Dato inválido"
"Dato inválido"
"Dato inválido"
"Incorrecto! 3 intentos"
None

'''