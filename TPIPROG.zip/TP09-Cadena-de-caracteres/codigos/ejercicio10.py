import random

# Paso [1]: Definir la función para convertir una cadena en geringoso
# La función toma una cadena como entrada y agrega sílabas geringosas aleatorias después de cada vocal en la cadena.
def geringoso(cadena):
    # Paso [1.1]: Definir las vocales para detectar en la cadena
    vocales = 'aeiouAEIOU'
    
    # Paso [1.2]: Definir las sílabas geringosas que se agregarán después de cada vocal
    silabas_geringosas = ['pa', 'pe', 'pi', 'po', 'pu']
    
    # Paso [1.3]: Inicializar una cadena vacía para construir la cadena geringosa resultante
    cadena_geringosa = ''
    
    # Paso [1.4]: Iterar sobre cada letra en la cadena original
    for letra in cadena:
        # Paso [1.4.1]: Agregar la letra actual a la cadena geringosa
        cadena_geringosa += letra
        
        # Paso [1.4.2]: Si la letra es una vocal, agregar una sílaba geringosa aleatoria
        if letra in vocales:
            # Elegir aleatoriamente una sílaba geringosa de la lista
            silaba = random.choice(silabas_geringosas)
            # Agregar la sílaba a la cadena geringosa
            cadena_geringosa += silaba
    
    # Paso [1.5]: Retornar la cadena con la modificación geringosa aplicada
    return cadena_geringosa

# Paso [2]: Definir una cadena de ejemplo para probar la función
cadena_original = "Hola mundo"

# Paso [3]: Llamar a la función geringoso con la cadena original y almacenar el resultado
resultado = geringoso(cadena_original)

# Paso [4]: Mostrar la cadena original en la consola
print("Cadena original:", cadena_original)

# Paso [5]: Mostrar la cadena modificada (geringosa) en la consola
print("Cadena geringosa:", resultado)
