import random

# Paso [1]: Inicializar una lista con datos de estudiantes para pruebas
# Esta lista simula una base de datos con 10 estudiantes, lo que facilita las pruebas de las funcionalidades del programa.
estudiantes = [
    ['12345678', 'Clave123', 'Juan Pérez', 'juan@example.com', '388-1234567'],
    ['23456789', 'Password1', 'María López', 'maria@example.com', '388-2345678'],
    ['34567890', 'SecurePass2', 'Pedro Gómez', 'pedro@example.com', '388-3456789'],
    ['45678901', 'StrongPass3', 'Ana Martínez', 'ana@example.com', '388-4567890'],
    ['56789012', 'Secret123', 'Luis Rodríguez', 'luis@example.com', '3886-5678901'],
    ['67890123', 'SuperPass4', 'Laura Sánchez', 'laura@example.com', '3886-6789012'],
    ['78901234', 'TopSecret5', 'Mariano Pérez', 'mariano@example.com', '3887-7890123'],
    ['89012345', 'Hidden678', 'Carolina López', 'carolina@example.com', '3888-8901234'],
    ['90123456', 'UltraPass6', 'Lucas González', 'lucas@example.com', '3888-9012345'],
    ['01234567', 'MegaPass7', 'Julieta Fernández', 'julieta@example.com', '3888-0123456']
]

# Paso [2]: Definir función para verificar si un DNI ya está registrado
# Esta función recorre la lista de estudiantes y retorna True si el DNI ya existe, lo que evita duplicados.
def dni_existe(dni):
    for estudiante in estudiantes:
        if estudiante[0] == dni:
            return True
    return False

# Paso [3]: Definir función para validar el formato del DNI
# El DNI debe ser un string de exactamente 8 dígitos. Si no cumple con esta condición, la función retorna False.
def validar_dni(dni):
    if len(dni) != 8 or not dni.isdigit():
        return False
    return True

# Paso [4]: Definir función para validar la clave del estudiante
# La clave debe tener al menos 6 caracteres, incluyendo al menos una mayúscula y un número para ser segura.
def validar_clave(clave):
    if len(clave) < 6:
        return False
    tiene_mayuscula = False
    tiene_numero = False
    for c in clave:
        if c.isupper():
            tiene_mayuscula = True
        if c.isdigit():
            tiene_numero = True
    return tiene_mayuscula and tiene_numero

# Paso [5]: Definir función para validar el nombre del estudiante
# El nombre no debe contener números ni caracteres especiales y debe tener al menos 3 caracteres.
def validar_nombre(nombre):
    if len(nombre) < 3:
        return False
    for c in nombre:
        if not c.isalpha() and c != ' ':
            return False
    return True

# Paso [6]: Definir función para validar el correo electrónico
# El correo debe contener un '@' que no esté ni al inicio ni al final de la cadena.
def validar_email(email):
    if '@' not in email or email.startswith('@') or email.endswith('@'):
        return False
    return True

# Paso [7]: Definir función para validar el número de celular
# El número de celular debe tener un código de área válido (388, 3886, 3887, 3888), un guion, y un número de 7 dígitos.
def validar_celular(celular):
    if '-' not in celular:
        return False
    codigo_area, numero = celular.split('-')
    if codigo_area not in ['388', '3886', '3887', '3888']:
        return False
    if len(numero) != 7 or not numero.isdigit():
        return False
    return True

# Paso [8]: Definir función para registrar un nuevo estudiante
# Se solicita al usuario que ingrese los datos del estudiante, y se validan cada uno de ellos.
# Si todos los datos son válidos, se agrega el estudiante a la lista de estudiantes.
def registrar_estudiante():
    print("Registro de nuevo estudiante:")
    
    # Validar el DNI
    dni = input("DNI (8 dígitos numéricos): ")
    while not validar_dni(dni) or dni_existe(dni):
        print("DNI inválido o ya registrado. Intente nuevamente.")
        dni = input("DNI (8 dígitos numéricos): ")
    
    # Validar la clave
    clave = input("Clave (mínimo 6 caracteres, al menos una mayúscula y un número): ")
    while not validar_clave(clave):
        print("Clave inválida. Intente nuevamente.")
        clave = input("Clave: ")
    
    # Validar el nombre
    nombre = input("Nombre (sin números ni caracteres especiales, al menos 3 caracteres): ")
    while not validar_nombre(nombre):
        print("Nombre inválido. Intente nuevamente.")
        nombre = input("Nombre: ")
    
    # Validar el correo electrónico
    email = input("Correo electrónico (debe contener '@' y no empezar ni terminar con '@'): ")
    while not validar_email(email):
        print("Correo electrónico inválido. Intente nuevamente.")
        email = input("Correo electrónico: ")
    
    # Validar el número de celular
    celular = input("Número de celular (código de área-guion-número, ej: 388-1234567): ")
    while not validar_celular(celular):
        print("Número de celular inválido. Intente nuevamente.")
        celular = input("Número de celular: ")
    
    # Agregar el estudiante a la lista de estudiantes
    estudiantes.append([dni, clave, nombre, email, celular])
    print("\nEstudiante registrado exitosamente.\n")

# Paso [9]: Definir función para buscar estudiantes por nombre
# Permite buscar estudiantes por nombre, mostrando todos si se deja el nombre en blanco o mostrando coincidencias si se ingresa un nombre parcial.
def buscar_estudiante_por_nombre(nombre_buscar):
    if nombre_buscar == '':
        print("\nListado completo de estudiantes:")
        for estudiante in estudiantes:
            print(f"DNI: {estudiante[0]}, Nombre: {estudiante[2]}, Email: {estudiante[3]}")
    else:
        print(f"\nEstudiantes cuyo nombre contiene '{nombre_buscar}':")
        encontrados = False
        for estudiante in estudiantes:
            if nombre_buscar.lower() in estudiante[2].lower():
                print(f"DNI: {estudiante[0]}, Nombre: {estudiante[2]}, Email: {estudiante[3]}")
                encontrados = True
        if not encontrados:
            print(f"No se encontraron estudiantes cuyo nombre contenga '{nombre_buscar}'.")
    print()

# Paso [10]: Definir función para realizar el login
# Verifica si el DNI y la clave ingresados coinciden con algún registro en la lista de estudiantes. 
# Si coinciden, muestra un mensaje de éxito y los datos del estudiante.
def login():
    dni = input("Ingrese su DNI: ")
    clave = input("Ingrese su clave: ")
    encontrado = False
    for estudiante in estudiantes:
        if estudiante[0] == dni and estudiante[1] == clave:
            print("\nIngreso exitoso.")
            print(f"Nombre: {estudiante[2]}, Email: {estudiante[3]}\n")
            encontrado = True
            break
    if not encontrado:
        print("\nUsuario o clave incorrectos.\n")

# Paso [11]: Ejecutar el programa con un ciclo que permite seleccionar entre registrar, buscar, ingresar o salir
# Este bucle permite la interacción continua con el usuario hasta que decida salir.
while True:
    print("\nBienvenido al sistema de registro de estudiantes\n")
    print("1. Registrar nuevo estudiante")
    print("2. Buscar estudiante por nombre")
    print("3. Ingresar (Login)")
    print("4. Salir")
    
    opcion = input("Ingrese la opción deseada: ")
    
    if opcion == '1':
        registrar_estudiante()
    elif opcion == '2':
        nombre_buscar = input("Ingrese el nombre del estudiante a buscar (deje vacío para listar todos): ")
        buscar_estudiante_por_nombre(nombre_buscar)
    elif opcion == '3':
        login()
    elif opcion == '4':
        print("\nGracias por utilizar el sistema. ¡Hasta luego!")
        break
    else:
        print("\nOpción inválida. Intente nuevamente.\n")
