# Paso [1]: Definir la función para modificar espacios en blanco
# Esta función toma una frase como entrada, elimina todos los espacios en blanco dobles o más, y deja solo un espacio en blanco entre las palabras.
def modificar_espacios(frase):
    # Paso [1.1]: Dividir la frase en una lista de palabras usando split(), lo que elimina automáticamente todos los espacios en blanco adicionales.
    palabras = frase.split()
    
    # Paso [1.2]: Unir las palabras de la lista con un solo espacio en blanco entre ellas, formando así la frase modificada.
    frase_modificada = ' '.join(palabras)
    
    # Paso [1.3]: Retornar la frase modificada al finalizar la función.
    return frase_modificada

# Paso [2]: Solicitar al usuario que ingrese una frase
# Esta entrada será procesada para eliminar los espacios en blanco innecesarios.
frase_original = input("Ingrese una frase: ")

# Paso [3]: Modificar los espacios en blanco en la frase según lo requerido
# Llamamos a la función modificar_espacios para procesar la frase ingresada.
frase_modificada = modificar_espacios(frase_original)

# Paso [4]: Mostrar la frase modificada
# Presentamos la frase con los espacios corregidos al usuario.
print("Frase modificada:", frase_modificada)
