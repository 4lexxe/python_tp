def s_sep(cadena, car):
    # Paso [1]: Inicializar una lista vacía para almacenar las palabras separadas.
    lpalabras = list()

    # Paso [2]: Verificar si el carácter separador está en la cadena.
    if car in cadena:
        # Paso [3]: Si el carácter está presente, dividir la cadena usando el separador y guardar el resultado en lpalabras.
        lpalabras = cadena.split(car)
    else:
        # Paso [4]: Si el carácter no está presente, imprimir un mensaje de "Ingreso inválido".
        print('Ingreso inválido')

    # Paso [5]: Retornar la lista de palabras (o una lista vacía si el separador no se encontró).
    return lpalabras

# Paso [6]: Mostrar un mensaje para guiar al usuario sobre cómo ingresar el texto y el separador.
mensaje = '''
Ingrese un texto y luego
un caracter separador por ejm:
Texto: 1-2-3-4
Separador: -
'''
print(mensaje)

# Paso [7]: Solicitar al usuario que ingrese un texto.
txt = input('Texto:')

# Paso [8]: Solicitar al usuario que ingrese un separador.
separador = input('Separador:')

# Paso [9]: Llamar a la función s_sep con el texto y el separador y almacenar la lista resultante.
lista = s_sep(txt, separador)

# Paso [10]: Imprimir la lista resultante.
print(lista)

'''

Aquí tienes el código del primer programa con comentarios que explican cada paso, junto con una prueba de escritorio y la salida esperada:

python
Copiar código
def s_sep(cadena, car):
    # Paso [1]: Inicializar una lista vacía para almacenar las palabras separadas.
    lpalabras = list()

    # Paso [2]: Verificar si el carácter separador está en la cadena.
    if car in cadena:
        # Paso [3]: Si el carácter está presente, dividir la cadena usando el separador y guardar el resultado en lpalabras.
        lpalabras = cadena.split(car)
    else:
        # Paso [4]: Si el carácter no está presente, imprimir un mensaje de "Ingreso inválido".
        print('Ingreso inválido')

    # Paso [5]: Retornar la lista de palabras (o una lista vacía si el separador no se encontró).
    return lpalabras

# Paso [6]: Mostrar un mensaje para guiar al usuario sobre cómo ingresar el texto y el separador.
mensaje = ''' '''
Ingrese un texto y luego
un caracter separador por ejm:
Texto: 1-2-3-4
Separador: - '''
'''
print(mensaje)

# Paso [7]: Solicitar al usuario que ingrese un texto.
txt = input('Texto:')

# Paso [8]: Solicitar al usuario que ingrese un separador.
separador = input('Separador:')

# Paso [9]: Llamar a la función s_sep con el texto y el separador y almacenar la lista resultante.
lista = s_sep(txt, separador)

# Paso [10]: Imprimir la lista resultante.
print(lista)
Prueba de escritorio:
Caso de prueba 1:

Entrada:
Texto: "1-2-3-4"
Separador: "-"
Proceso:
La cadena "1-2-3-4" se divide por "-" en ['1', '2', '3', '4'].
Salida esperada:
['1', '2', '3', '4']
Caso de prueba 2:

Entrada:
Texto: "192.168.0.1"
Separador: "."
Proceso:
La cadena "192.168.0.1" se divide por "." en ['192', '168', '0', '1'].
Salida esperada:
['192', '168', '0', '1']
Caso de prueba 3:

Entrada:
Texto: "192.168.0.1"
Separador: "-"
Proceso:
Como "-" no está en la cadena, se imprime "Ingreso inválido" y se retorna una lista vacía.
Salida esperada:
"Ingreso inválido"
[]

'''